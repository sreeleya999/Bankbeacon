-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 01, 2023 at 06:24 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bank_new`
--

-- --------------------------------------------------------

--
-- Table structure for table `calender`
--

CREATE TABLE `calender` (
  `calender_id` int(25) NOT NULL,
  `day_no` int(25) NOT NULL,
  `week_no` int(25) NOT NULL,
  `month_no` varchar(35) NOT NULL,
  `year_no` int(35) NOT NULL,
  `event` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `calender`
--

INSERT INTO `calender` (`calender_id`, `day_no`, `week_no`, `month_no`, `year_no`, `event`) VALUES
(1, 15, 2, '4', 2023, 'vishu'),
(2, 26, 3, '1', 2023, 'Republic Day'),
(3, 14, 2, '1', 2023, 'second saturday'),
(5, 1, 1, '5', 2023, 'May Day'),
(6, 12, 3, '11', 2023, 'Developers Day');

-- --------------------------------------------------------

--
-- Table structure for table `chequebook`
--

CREATE TABLE `chequebook` (
  `id` int(11) NOT NULL,
  `acNo` varchar(150) NOT NULL,
  `duration` varchar(150) NOT NULL,
  `date` date NOT NULL,
  `reg_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `complaint`
--

CREATE TABLE `complaint` (
  `id` int(11) NOT NULL,
  `type` varchar(100) NOT NULL,
  `complaint` varchar(300) NOT NULL,
  `reg_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `complaint`
--

INSERT INTO `complaint` (`id`, `type`, `complaint`, `reg_id`) VALUES
(1, 'transaction', 'incomplete transaction', 5);

-- --------------------------------------------------------

--
-- Table structure for table `emi`
--

CREATE TABLE `emi` (
  `emi_id` int(15) NOT NULL,
  `amount` int(150) NOT NULL,
  `interest` int(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `feedback_id` int(25) NOT NULL,
  `reg_id` int(25) NOT NULL,
  `feedback` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`feedback_id`, `reg_id`, `feedback`) VALUES
(1, 2, 'nice'),
(2, 5, 'helpful');

-- --------------------------------------------------------

--
-- Table structure for table `flash`
--

CREATE TABLE `flash` (
  `offer_id` int(15) NOT NULL,
  `reg_id` varchar(40) NOT NULL,
  `mobile_no` int(35) NOT NULL,
  `offer_type` varchar(350) NOT NULL,
  `account_no` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `flash`
--

INSERT INTO `flash` (`offer_id`, `reg_id`, `mobile_no`, `offer_type`, `account_no`) VALUES
(1, '1', 2147483647, 'loan type', 0),
(2, '2', 12345000, 'loan type', 455666),
(9, '2', 56678872, 'education loan', 2147483647),
(10, '1', 2147483647, 'jfghjd', 11223344);

-- --------------------------------------------------------

--
-- Table structure for table `generatepin`
--

CREATE TABLE `generatepin` (
  `account_id` int(25) NOT NULL,
  `reg_id` int(15) NOT NULL,
  `card_no` int(25) NOT NULL,
  `card_status` varchar(35) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `generatepin`
--

INSERT INTO `generatepin` (`account_id`, `reg_id`, `card_no`, `card_status`) VALUES
(1, 2, 12436, '0'),
(2, 2, 4567, '1'),
(3, 0, 0, '0'),
(4, 4, 1522, '0');

-- --------------------------------------------------------

--
-- Table structure for table `greenpin`
--

CREATE TABLE `greenpin` (
  `atm_id` int(11) NOT NULL,
  `reg_id` int(15) NOT NULL,
  `account_no` int(11) NOT NULL,
  `debitcard_no` int(15) NOT NULL,
  `card_status` varchar(35) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `greenpin`
--

INSERT INTO `greenpin` (`atm_id`, `reg_id`, `account_no`, `debitcard_no`, `card_status`) VALUES
(1, 0, 2147483647, 1234, '0'),
(2, 0, 455666, 4567, '0'),
(6, 2, 1234, 4321, '1'),
(7, 5, 8745, 9060, '0');

-- --------------------------------------------------------

--
-- Table structure for table `insurance`
--

CREATE TABLE `insurance` (
  `insure_id` int(15) NOT NULL,
  `reg_id` varchar(40) NOT NULL,
  `account_no` varchar(150) NOT NULL,
  `phone_no` bigint(150) NOT NULL,
  `email` varchar(250) NOT NULL,
  `insurance_type` varchar(35) NOT NULL,
  `insurance_status` varchar(35) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `insurance`
--

INSERT INTO `insurance` (`insure_id`, `reg_id`, `account_no`, `phone_no`, `email`, `insurance_type`, `insurance_status`) VALUES
(3, '2', '2147483647', 2147483647, 'sreyaleya999@gmail.com', 'life', '1'),
(4, '3', 'CNB12004624', 8563256341, 'mihir@gmail.com', 'Health', '0'),
(5, '3', 'CNB12004500', 8086452420, 'shanoob12@gmail.com', 'Life', '0'),
(6, '3', 'PNB12123030456', 9856995510, 'manu2002@gmail.com', 'Travel', '0'),
(7, '3', 'PNB120130150', 8086612451, 'Sreema4141@gmail.com', 'Vehicle', '0'),
(8, '5', 'PNB74000120', 9445521010, 'binu1010@gmail.com', 'Travel', '0');

-- --------------------------------------------------------

--
-- Table structure for table `loan`
--

CREATE TABLE `loan` (
  `loan_id` int(11) NOT NULL,
  `reg_id` varchar(11) NOT NULL,
  `account_no` varchar(15) NOT NULL,
  `mobile_no` bigint(11) NOT NULL,
  `email` varchar(11) NOT NULL,
  `loan_type` varchar(11) NOT NULL,
  `loan_status` varchar(35) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `loan`
--

INSERT INTO `loan` (`loan_id`, `reg_id`, `account_no`, `mobile_no`, `email`, `loan_type`, `loan_status`) VALUES
(2, '', '455666', 12345, 'sreyaleya@g', 'education', 'approved'),
(3, 'charu', '455666', 12345, 'sreyaleya@g', 'vechile', 'approved'),
(4, 'Cutomer nam', '2147483647', 2147483647, 'freenafranc', 'homeloan', 'approved'),
(5, '2', '2147483647', 2147483647, 'achu@gmail.', 'home', '0'),
(7, '2', '1234', 2147483647, 'aju@123', 'education', '1'),
(8, '2', 'PNB1234002', 9856585820, 'nila123nila', 'home', '0'),
(9, '3', 'PNB100989898', 9874563210, 'mahi@gmail.', 'home', '0'),
(10, '3', 'CNB100909090', 9874652130, 'mahi123@gma', 'education', '0'),
(11, '3', 'PNB202000013', 9875856985, 'nikil157@gm', 'gold', '1'),
(12, '3', 'CNB5220980', 7896582010, 'anupama45@g', 'gold', '0'),
(13, '3', 'PNB10008907', 8756254120, 'sanosh10@gm', 'personal', '0'),
(18, '5', 'CNB10009870', 8575451210, 'binu1010@gm', 'personal', '0');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `login_id` int(11) NOT NULL,
  `username` varchar(40) NOT NULL,
  `password` varchar(20) NOT NULL,
  `type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`login_id`, `username`, `password`, `type`) VALUES
(1, 'admin', 'admin', 'admin'),
(2, 'nila123', '123123', 'user'),
(3, 'mahi123', '909090', 'user'),
(4, 'nikitha123', '123456', 'user'),
(5, 'binu1010', '909090', 'user');

-- --------------------------------------------------------

--
-- Table structure for table `meet_request`
--

CREATE TABLE `meet_request` (
  `id` int(11) NOT NULL,
  `reg_id` int(11) NOT NULL,
  `reason` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `meet_request`
--

INSERT INTO `meet_request` (`id`, `reg_id`, `reason`) VALUES
(1, 3, 'sbahbahb jhas dbashudba xbashxb'),
(2, 4, 'if DF ffef fefef ewfsf FSffe');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `notification_id` int(35) NOT NULL,
  `reg_id` int(11) NOT NULL,
  `mobile_no` int(150) NOT NULL,
  `title` varchar(150) NOT NULL,
  `content` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`notification_id`, `reg_id`, `mobile_no`, `title`, `content`) VALUES
(7, 0, 2147483647, 'your ac credited 300/-', ''),
(10, 0, 2147483647, 'loan', 'sucessfully approved'),
(11, 2, 2147483647, '', 'sucessfully approved'),
(13, 3, 2147483647, 'register', 'register successfully'),
(16, 2, 702590668, 'register', 'successfully register');

-- --------------------------------------------------------

--
-- Table structure for table `recharge`
--

CREATE TABLE `recharge` (
  `customer_id` int(15) NOT NULL,
  `reg_id` int(35) NOT NULL,
  `operator_status` varchar(150) NOT NULL,
  `amount` int(35) NOT NULL,
  `mobile_no` bigint(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `recharge`
--

INSERT INTO `recharge` (`customer_id`, `reg_id`, `operator_status`, `amount`, `mobile_no`) VALUES
(1, 0, 'BSNL', 150, 965692332),
(2, 5, '', 249, 9947521210);

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `reg_id` int(11) NOT NULL,
  `Firstname` varchar(30) NOT NULL,
  `Lastname` varchar(30) NOT NULL,
  `log_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`reg_id`, `Firstname`, `Lastname`, `log_id`) VALUES
(1, 'nikhil', 'k', 0),
(2, 'akhil', 'm', 0),
(3, 'nila', 'nila', 2),
(4, 'mahesh', 'mahesh', 3),
(5, 'Nikitha', 'kumari', 4),
(6, 'Binu', 'Binisha', 5);

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `schedule_id` int(35) NOT NULL,
  `reg_id` varchar(35) NOT NULL,
  `schudule_type` varchar(150) NOT NULL,
  `schudule_time` int(150) NOT NULL,
  `message` varchar(350) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`schedule_id`, `reg_id`, `schudule_type`, `schudule_time`, `message`) VALUES
(0, '1', 'meeting', 12, 'scheduling time at 12.00pm');

-- --------------------------------------------------------

--
-- Table structure for table `totalaccounts`
--

CREATE TABLE `totalaccounts` (
  `account_id` int(15) NOT NULL,
  `customer_name` varchar(25) NOT NULL,
  `mobile_no` int(80) NOT NULL,
  `email` varchar(150) NOT NULL,
  `account_type` varchar(35) NOT NULL,
  `account_status` int(90) NOT NULL DEFAULT 0,
  `checkbook_status` varchar(150) NOT NULL DEFAULT '0',
  `acc_no` varchar(39) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `totalaccounts`
--

INSERT INTO `totalaccounts` (`account_id`, `customer_name`, `mobile_no`, `email`, `account_type`, `account_status`, `checkbook_status`, `acc_no`) VALUES
(1, 'sreya', 965692332, 'sreya@gmail.com', 'saving', 0, '0', '0000987');

-- --------------------------------------------------------

--
-- Table structure for table `totalcustomer`
--

CREATE TABLE `totalcustomer` (
  `customer_id` int(15) NOT NULL,
  `reg_id` varchar(45) NOT NULL,
  `card_no` int(35) NOT NULL,
  `account_type` varchar(25) NOT NULL,
  `account_status` varchar(35) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `totalcustomer`
--

INSERT INTO `totalcustomer` (`customer_id`, `reg_id`, `card_no`, `account_type`, `account_status`) VALUES
(3, '2', 234000123, 'saving', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tracking`
--

CREATE TABLE `tracking` (
  `id` int(11) NOT NULL,
  `type` varchar(150) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `reg_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tracking`
--

INSERT INTO `tracking` (`id`, `type`, `mobile`, `reg_id`) VALUES
(1, 'abc', 8545751010, 5);

-- --------------------------------------------------------

--
-- Table structure for table `transaction_id`
--

CREATE TABLE `transaction_id` (
  `transaction_id` int(15) NOT NULL,
  `reg_id` varchar(25) NOT NULL,
  `transaction_type` varchar(35) NOT NULL,
  `amount` int(150) NOT NULL,
  `mobile_no` bigint(120) NOT NULL,
  `account_no` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaction_id`
--

INSERT INTO `transaction_id` (`transaction_id`, `reg_id`, `transaction_type`, `amount`, `mobile_no`, `account_no`) VALUES
(1, '2', 'deposit', 5000, 965692332, 'PNB4512001'),
(2, '3', 'withdraw', 5000, 965692332, 'CSB4512010'),
(3, '3', 'Transfer', 85000, 8547521010, 'CNB8501210'),
(4, '3', 'Withdraw', 5000, 9874521012, 'PNB0011290'),
(5, '3', 'Withdraw', 5000, 8545210102, 'CNB1002100'),
(6, '3', 'Deposit', 12000, 9856231021, 'PNB2005120'),
(7, '4', 'Transfer', 4500, 8745254101, '4521780124'),
(8, '4', 'Withdraw', 12000, 8569856210, 'CSB12358745000'),
(9, '4', 'Deposit', 45000, 9856210140, 'CSB24815411');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `calender`
--
ALTER TABLE `calender`
  ADD PRIMARY KEY (`calender_id`);

--
-- Indexes for table `chequebook`
--
ALTER TABLE `chequebook`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `complaint`
--
ALTER TABLE `complaint`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `emi`
--
ALTER TABLE `emi`
  ADD PRIMARY KEY (`emi_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`feedback_id`);

--
-- Indexes for table `flash`
--
ALTER TABLE `flash`
  ADD PRIMARY KEY (`offer_id`);

--
-- Indexes for table `generatepin`
--
ALTER TABLE `generatepin`
  ADD PRIMARY KEY (`account_id`);

--
-- Indexes for table `greenpin`
--
ALTER TABLE `greenpin`
  ADD PRIMARY KEY (`atm_id`);

--
-- Indexes for table `insurance`
--
ALTER TABLE `insurance`
  ADD PRIMARY KEY (`insure_id`);

--
-- Indexes for table `loan`
--
ALTER TABLE `loan`
  ADD PRIMARY KEY (`loan_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`login_id`);

--
-- Indexes for table `meet_request`
--
ALTER TABLE `meet_request`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`notification_id`);

--
-- Indexes for table `recharge`
--
ALTER TABLE `recharge`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`reg_id`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`schedule_id`);

--
-- Indexes for table `totalaccounts`
--
ALTER TABLE `totalaccounts`
  ADD PRIMARY KEY (`account_id`);

--
-- Indexes for table `totalcustomer`
--
ALTER TABLE `totalcustomer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `tracking`
--
ALTER TABLE `tracking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaction_id`
--
ALTER TABLE `transaction_id`
  ADD PRIMARY KEY (`transaction_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `calender`
--
ALTER TABLE `calender`
  MODIFY `calender_id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `chequebook`
--
ALTER TABLE `chequebook`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `complaint`
--
ALTER TABLE `complaint`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `emi`
--
ALTER TABLE `emi`
  MODIFY `emi_id` int(15) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `feedback_id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `flash`
--
ALTER TABLE `flash`
  MODIFY `offer_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `generatepin`
--
ALTER TABLE `generatepin`
  MODIFY `account_id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `greenpin`
--
ALTER TABLE `greenpin`
  MODIFY `atm_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `insurance`
--
ALTER TABLE `insurance`
  MODIFY `insure_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `loan`
--
ALTER TABLE `loan`
  MODIFY `loan_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `login_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `meet_request`
--
ALTER TABLE `meet_request`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `notification_id` int(35) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `recharge`
--
ALTER TABLE `recharge`
  MODIFY `customer_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `reg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `totalaccounts`
--
ALTER TABLE `totalaccounts`
  MODIFY `account_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `totalcustomer`
--
ALTER TABLE `totalcustomer`
  MODIFY `customer_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tracking`
--
ALTER TABLE `tracking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `transaction_id`
--
ALTER TABLE `transaction_id`
  MODIFY `transaction_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
